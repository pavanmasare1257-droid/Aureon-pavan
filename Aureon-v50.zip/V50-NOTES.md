# v50 - Ava / AI band hone ki asli wajah
AI check ne dikhaya: Gemini 2.5-flash / 2.5-flash-lite "no longer available to new users" (404), Groq ke llama-3.3-70b aur llama-3.1-8b tumhare account me nahi, aur ek Gemini + ek Groq key invalid (401).
- llm-text.js: model naam ab fixed nahi. Pehle API se pucha jata hai ki key kaun se models chala sakti hai (har 6 ghante), 404 ke "use models/X" hint se naya naam turant seekha jata hai aur usi call me dobara try hota hai. Groq: gpt-oss ke liye reasoning_effort=low (khali jawab nahi).
- AI check: har key ka ek line me haal (OK / GALAT), phir detail.
- Isse Ava ke upgrades/prototypes, Ava Studio, APK Studio, Apps & Automation sab (llm-text use karte hain) wapas chalenge.
Deploy: backend => Render redeploy.
